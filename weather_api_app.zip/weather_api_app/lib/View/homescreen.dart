import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:weather_api_app/View/weather_details.dart';

import '../ViewModel/weather_viewmodel.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _controller = TextEditingController();

  void _searchWeather() async {
    await Provider.of<WeatherViewModel>(context, listen: false)
        .fetchWeather(_controller.text);

    if (Provider.of<WeatherViewModel>(context, listen: false).error.isEmpty) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => WeatherDetailsScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final weatherViewModel = Provider.of<WeatherViewModel>(context);



    return Scaffold(
      appBar: AppBar(
        title: Text('Weather App'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Enter city name',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: _searchWeather,
              child: Text('Search'),
            ),
            SizedBox(height: 16),
            if (weatherViewModel.loading) CircularProgressIndicator(),
            if (weatherViewModel.error.isNotEmpty)
              Text(weatherViewModel.error, style: TextStyle(color: Colors.red)),
          ],
        ),
      ),
    );
  }
}
