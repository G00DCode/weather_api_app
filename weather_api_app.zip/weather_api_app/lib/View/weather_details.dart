import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../ViewModel/weather_viewmodel.dart';

class WeatherDetailsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final weatherViewModel = Provider.of<WeatherViewModel>(context);
    final weather = weatherViewModel.weather;

    return Scaffold(
      appBar: AppBar(
        title: Text('Weather Details'),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: () {
              weatherViewModel.fetchWeather(weather!.city);
            },
          )
        ],
      ),
      body: weatherViewModel.loading
          ? Center(child: CircularProgressIndicator())
          : weather == null
          ? Center(child: Text(weatherViewModel.error))
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              weather.city,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            Text(
              '${weather.temperature}°C',
              style: TextStyle(fontSize: 48),
            ),
            Text(weather.condition),
            Image.network('http://openweathermap.org/img/wn/${weather.icon}@2x.png'),
            SizedBox(height: 16),
            Text('Humidity: ${weather.humidity}%', style: TextStyle(fontSize: 18)),
            SizedBox(height: 8),
            Text('Wind speed: ${weather.windSpeed} m/s', style: TextStyle(fontSize: 18)),
          ],
        ),
      ),
    );
  }
}
